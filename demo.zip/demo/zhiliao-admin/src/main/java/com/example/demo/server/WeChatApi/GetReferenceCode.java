package com.example.demo.server.WeChatApi;

//@Service
public class GetReferenceCode {
   private final GetAccessToken getAccessToken;

    public GetReferenceCode(GetAccessToken getAccessToken) {
        this.getAccessToken = getAccessToken;
    }
}
